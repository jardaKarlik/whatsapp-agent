import pkg from 'whatsapp-web.js';
const { Client, LocalAuth } = pkg;
import qrcode from 'qrcode-terminal';
import Anthropic from '@anthropic-ai/sdk';
import Database from 'better-sqlite3';
import { readFileSync } from 'fs';
import 'dotenv/config';

const config = JSON.parse(readFileSync('./config.json', 'utf8'));
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const db = new Database('./queue.db');

// ── DB setup ──────────────────────────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS queue (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    datetime TEXT,
    chat_name TEXT,
    raw_messages TEXT,
    status TEXT DEFAULT 'pending',
    created_at TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS message_buffer (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id TEXT NOT NULL,
    chat_name TEXT NOT NULL,
    sender TEXT,
    body TEXT NOT NULL,
    ts INTEGER NOT NULL
  );
`);

const insertBuffer = db.prepare(
  'INSERT INTO message_buffer (chat_id, chat_name, sender, body, ts) VALUES (?,?,?,?,?)'
);
const clearBuffer  = db.prepare('DELETE FROM message_buffer WHERE chat_id = ?');
const getBuffer    = db.prepare('SELECT * FROM message_buffer WHERE chat_id = ? ORDER BY ts ASC');
const insertQueue  = db.prepare(
  'INSERT INTO queue (type, title, description, datetime, chat_name, raw_messages) VALUES (?,?,?,?,?,?)'
);

// ── Buffer timers ─────────────────────────────────────────────────────────────
const timers = {};

function scheduleAnalysis(chatId, chatName) {
  if (timers[chatId]) clearTimeout(timers[chatId]);
  timers[chatId] = setTimeout(() => analyzeBuffer(chatId, chatName), config.bufferMinutes * 60 * 1000);
}

async function analyzeBuffer(chatId, chatName) {
  const rows = getBuffer.all(chatId);
  if (!rows.length) return;
  clearBuffer.run(chatId);

  const transcript = rows
    .map(r => `[${new Date(r.ts).toLocaleTimeString()}] ${r.sender}: ${r.body}`)
    .join('\n');

  console.log(`\n🔍 Analyzing ${rows.length} messages from "${chatName}"…`);

  const today = new Date().toISOString().slice(0, 10);

  const prompt = `You are an assistant that reads WhatsApp conversation excerpts and extracts two kinds of items:

1. COMMITMENT — a personal pledge to do something (e.g. "I'll call you", "I'll check that", "I'll send it over")
2. EVENT — a scheduled meeting or appointment with a date/time (e.g. "Let's meet Friday at 6", "See you there at 5")

Today's date is ${today}.

Analyse the conversation below and return ONLY valid JSON — no markdown, no preamble:
{
  "items": [
    {
      "type": "commitment" | "event",
      "title": "short action title (max 8 words)",
      "description": "one sentence summary with relevant context",
      "datetime": "ISO 8601 string if determinable, otherwise null",
      "confidence": 0.0-1.0
    }
  ]
}

If nothing qualifies, return { "items": [] }.

Rules:
- Skip vague or hypothetical statements ("maybe we should…", "we could try…")
- Skip things already in the past
- Only include items with confidence >= 0.7
- For commitments without a clear time, set datetime to null

Conversation:
${transcript}`;

  try {
    const response = await anthropic.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 1024,
      messages: [{ role: 'user', content: prompt }]
    });

    const raw = response.content[0].text.trim();
    const parsed = JSON.parse(raw);

    if (!parsed.items?.length) {
      console.log('   → No items detected.');
      return;
    }

    for (const item of parsed.items) {
      insertQueue.run(
        item.type,
        item.title,
        item.description,
        item.datetime,
        chatName,
        transcript
      );
      console.log(`   ✅ Queued [${item.type}]: ${item.title}`);
    }
  } catch (err) {
    console.error('   ❌ Analysis error:', err.message);
  }
}

// ── WhatsApp client ───────────────────────────────────────────────────────────
const client = new Client({
  authStrategy: new LocalAuth(),
  puppeteer: { args: ['--no-sandbox', '--disable-setuid-sandbox'] }
});

client.on('qr', qr => {
  console.log('\n📱 Scan this QR code with WhatsApp:\n');
  qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
  console.log('\n✅ WhatsApp agent is running.');
  console.log(`📋 Watching ${config.watchedChats.length} chat(s): ${config.watchedChats.join(', ')}`);
  console.log(`⏱  Buffer window: ${config.bufferMinutes} min`);
  console.log('🌐 Review UI: http://localhost:3000\n');
});

client.on('message', async msg => {
  const chat = await msg.getChat();
  const chatName = chat.name || msg.from;

  const isWatched = config.watchedChats.some(
    w => chatName.toLowerCase().includes(w.toLowerCase())
  );
  if (!isWatched) return;

  const contact = await msg.getContact();
  const sender = contact.pushname || contact.number || 'Unknown';

  insertBuffer.run(chat.id._serialized, chatName, sender, msg.body, Date.now());
  console.log(`💬 Buffered message from "${chatName}" (${sender})`);
  scheduleAnalysis(chat.id._serialized, chatName);
});

client.on('disconnected', reason => {
  console.log('⚠️  WhatsApp disconnected:', reason);
});

client.initialize();
