import express from 'express';
import Database from 'better-sqlite3';
import { google } from 'googleapis';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { createServer } from 'http';
import 'dotenv/config';

const app = express();
app.use(express.json());
app.use(express.static('public'));

const db = new Database('./queue.db');
const PORT = 3000;

// ── Google OAuth ──────────────────────────────────────────────────────────────
const credentials = JSON.parse(readFileSync('./credentials.json', 'utf8'));
const { client_id, client_secret, redirect_uris } = credentials.installed;

const oauth2Client = new google.auth.OAuth2(
  client_id, client_secret, 'http://localhost:3000/oauth2callback'
);

// Load saved tokens if present
if (existsSync('./tokens.json')) {
  oauth2Client.setCredentials(JSON.parse(readFileSync('./tokens.json', 'utf8')));
}

oauth2Client.on('tokens', tokens => {
  const existing = existsSync('./tokens.json')
    ? JSON.parse(readFileSync('./tokens.json', 'utf8'))
    : {};
  writeFileSync('./tokens.json', JSON.stringify({ ...existing, ...tokens }, null, 2));
});

const calendar = google.calendar({ version: 'v3', auth: oauth2Client });
const tasks    = google.tasks({ version: 'v1', auth: oauth2Client });

// ── Auth routes ───────────────────────────────────────────────────────────────
app.get('/auth', (req, res) => {
  const url = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: [
      'https://www.googleapis.com/auth/calendar',
      'https://www.googleapis.com/auth/tasks'
    ]
  });
  res.redirect(url);
});

app.get('/oauth2callback', async (req, res) => {
  const { tokens } = await oauth2Client.getToken(req.query.code);
  oauth2Client.setCredentials(tokens);
  writeFileSync('./tokens.json', JSON.stringify(tokens, null, 2));
  res.redirect('/');
});

// ── API routes ────────────────────────────────────────────────────────────────
app.get('/api/queue', (req, res) => {
  const items = db.prepare(
    "SELECT * FROM queue WHERE status = 'pending' ORDER BY created_at DESC"
  ).all();
  res.json(items);
});

app.get('/api/done', (req, res) => {
  const items = db.prepare(
    "SELECT * FROM queue WHERE status != 'pending' ORDER BY created_at DESC LIMIT 50"
  ).all();
  res.json(items);
});

app.post('/api/approve/:id', async (req, res) => {
  const item = db.prepare('SELECT * FROM queue WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Not found' });

  const { title, description, datetime, type } = { ...item, ...req.body };

  try {
    if (type === 'event') {
      const start = datetime
        ? new Date(datetime)
        : (() => { const d = new Date(); d.setDate(d.getDate() + 1); d.setHours(10, 0, 0, 0); return d; })();
      const end = new Date(start.getTime() + 60 * 60 * 1000);

      const event = await calendar.events.insert({
        calendarId: 'primary',
        requestBody: {
          summary: title,
          description: description || '',
          start: { dateTime: start.toISOString() },
          end:   { dateTime: end.toISOString() }
        }
      });
      db.prepare("UPDATE queue SET status = 'approved' WHERE id = ?").run(item.id);
      res.json({ ok: true, link: event.data.htmlLink });

    } else {
      // commitment → Google Task
      let taskListId = '@default';
      try {
        const lists = await tasks.tasklists.list();
        const waList = lists.data.items?.find(l => l.title === 'WhatsApp');
        if (waList) {
          taskListId = waList.id;
        } else {
          const newList = await tasks.tasklists.insert({ requestBody: { title: 'WhatsApp' } });
          taskListId = newList.data.id;
        }
      } catch (_) {}

      const due = datetime ? new Date(datetime).toISOString() : undefined;
      await tasks.tasks.insert({
        tasklist: taskListId,
        requestBody: {
          title,
          notes: [description || '', `From: ${item.chat_name}`].filter(Boolean).join('\n'),
          ...(due ? { due } : {})
        }
      });
      db.prepare("UPDATE queue SET status = 'approved' WHERE id = ?").run(item.id);
      res.json({ ok: true });
    }
  } catch (err) {
    console.error('Google API error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/reject/:id', (req, res) => {
  db.prepare("UPDATE queue SET status = 'rejected' WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

// ── Serve UI ──────────────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.send(getHTML());
});

function getHTML() {
  const isAuthed = existsSync('./tokens.json');
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>WhatsApp Agent</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f5f5f5;color:#1a1a1a;min-height:100vh}
    header{background:#fff;border-bottom:1px solid #e5e5e5;padding:16px 24px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:10}
    header h1{font-size:18px;font-weight:600;letter-spacing:-.3px}
    .badge{font-size:12px;background:#25D366;color:#fff;border-radius:12px;padding:2px 10px;font-weight:500}
    .auth-btn{background:#4285F4;color:#fff;border:none;border-radius:8px;padding:8px 16px;font-size:13px;cursor:pointer;text-decoration:none;display:inline-block}
    main{max-width:680px;margin:0 auto;padding:24px 16px}
    .section-title{font-size:13px;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:.5px;margin-bottom:12px}
    .empty{text-align:center;padding:48px 24px;color:#9ca3af;font-size:14px}
    .card{background:#fff;border-radius:12px;border:1px solid #e5e5e5;padding:16px;margin-bottom:10px;transition:box-shadow .15s}
    .card:hover{box-shadow:0 2px 8px rgba(0,0,0,.08)}
    .card-header{display:flex;align-items:flex-start;gap:10px;margin-bottom:8px}
    .chip{font-size:11px;font-weight:600;padding:3px 8px;border-radius:6px;white-space:nowrap;flex-shrink:0;margin-top:1px}
    .chip-event{background:#EEF2FF;color:#4338CA}
    .chip-commitment{background:#F0FDF4;color:#15803D}
    .card-title{font-size:15px;font-weight:600;flex:1;line-height:1.3}
    .card-meta{font-size:12px;color:#6b7280;margin-bottom:10px;display:flex;gap:12px;flex-wrap:wrap}
    .card-meta span{display:flex;align-items:center;gap:4px}
    .actions{display:flex;gap:8px}
    .btn{border:none;border-radius:8px;padding:7px 14px;font-size:13px;font-weight:500;cursor:pointer;transition:opacity .15s}
    .btn:hover{opacity:.85}
    .btn-approve{background:#25D366;color:#fff}
    .btn-reject{background:#f3f4f6;color:#374151}
    .edit-row{margin-bottom:10px;display:flex;flex-direction:column;gap:6px}
    .edit-row input{border:1px solid #e5e5e5;border-radius:8px;padding:6px 10px;font-size:13px;width:100%;outline:none}
    .edit-row input:focus{border-color:#4285F4}
    .done-section{margin-top:32px;opacity:.7}
    .done-card{display:flex;align-items:center;gap:10px;padding:10px 14px;background:#fff;border-radius:8px;border:1px solid #e5e5e5;margin-bottom:6px;font-size:13px}
    .status-approved{color:#15803D;font-weight:600}
    .status-rejected{color:#9ca3af}
    .toast{position:fixed;bottom:24px;right:24px;background:#1a1a1a;color:#fff;padding:10px 16px;border-radius:10px;font-size:13px;opacity:0;transition:opacity .3s;pointer-events:none;z-index:999}
    .toast.show{opacity:1}
    .context-toggle{font-size:11px;color:#9ca3af;cursor:pointer;margin-left:auto;background:none;border:none;padding:0}
    .context-box{display:none;margin-top:8px;background:#f9fafb;border-radius:8px;padding:10px;font-size:11px;color:#6b7280;white-space:pre-wrap;max-height:120px;overflow-y:auto;line-height:1.5}
    .context-box.open{display:block}
  </style>
</head>
<body>
<header>
  <h1>WhatsApp Agent</h1>
  <div style="display:flex;align-items:center;gap:10px">
    <span id="count-badge" class="badge">0 pending</span>
    ${isAuthed ? '<span style="font-size:12px;color:#15803D">● Connected to Google</span>' : '<a href="/auth" class="auth-btn">Connect Google</a>'}
  </div>
</header>
<main>
  <div id="pending-section">
    <p class="section-title">Pending review</p>
    <div id="pending-list"><p class="empty">No items waiting for review.</p></div>
  </div>
  <div id="done-section" class="done-section" style="display:none">
    <p class="section-title">Recently processed</p>
    <div id="done-list"></div>
  </div>
</main>
<div class="toast" id="toast"></div>
<script>
  let pendingItems = [];

  async function load() {
    const [pending, done] = await Promise.all([
      fetch('/api/queue').then(r=>r.json()),
      fetch('/api/done').then(r=>r.json())
    ]);
    pendingItems = pending;
    renderPending(pending);
    renderDone(done);
    document.getElementById('count-badge').textContent = pending.length + ' pending';
  }

  function renderPending(items) {
    const el = document.getElementById('pending-list');
    if (!items.length) { el.innerHTML = '<p class="empty">Nothing to review right now.</p>'; return; }
    el.innerHTML = items.map(item => {
      const chipClass = item.type === 'event' ? 'chip-event' : 'chip-commitment';
      const chipLabel = item.type === 'event' ? 'Event' : 'Task';
      const dtDisplay = item.datetime ? new Date(item.datetime).toLocaleString() : 'No date set';
      return \`
      <div class="card" id="card-\${item.id}">
        <div class="card-header">
          <span class="chip \${chipClass}">\${chipLabel}</span>
          <span class="card-title" contenteditable="true" id="title-\${item.id}">\${esc(item.title)}</span>
          <button class="context-toggle" onclick="toggleContext(\${item.id})">context</button>
        </div>
        <div class="card-meta">
          <span>💬 \${esc(item.chat_name)}</span>
          <span>🕐 \${esc(dtDisplay)}</span>
        </div>
        <div class="edit-row">
          <input id="desc-\${item.id}" value="\${esc(item.description||'')}" placeholder="Description…"/>
          <input id="dt-\${item.id}" type="datetime-local" value="\${toInputDT(item.datetime)}"/>
        </div>
        <div class="context-box" id="ctx-\${item.id}">\${esc(item.raw_messages||'')}</div>
        <div class="actions">
          <button class="btn btn-approve" onclick="approve(\${item.id})">✓ Approve</button>
          <button class="btn btn-reject" onclick="reject(\${item.id})">✕ Dismiss</button>
        </div>
      </div>\`;
    }).join('');
  }

  function renderDone(items) {
    const section = document.getElementById('done-section');
    const el = document.getElementById('done-list');
    if (!items.length) { section.style.display='none'; return; }
    section.style.display='block';
    el.innerHTML = items.map(item => \`
      <div class="done-card">
        <span class="chip \${item.type==='event'?'chip-event':'chip-commitment'}">\${item.type==='event'?'Event':'Task'}</span>
        <span style="flex:1">\${esc(item.title)}</span>
        <span class="status-\${item.status}">\${item.status}</span>
      </div>
    \`).join('');
  }

  async function approve(id) {
    const title = document.getElementById('title-'+id).innerText.trim();
    const description = document.getElementById('desc-'+id).value.trim();
    const rawDt = document.getElementById('dt-'+id).value;
    const datetime = rawDt ? new Date(rawDt).toISOString() : null;
    const item = pendingItems.find(i=>i.id===id);

    const res = await fetch('/api/approve/'+id, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({title,description,datetime,type:item?.type})
    });
    const data = await res.json();
    if (data.ok) {
      toast(item?.type==='event' ? '📅 Event added to Calendar' : '✅ Task added to Google Tasks');
      load();
    } else {
      toast('❌ Error: '+data.error, true);
    }
  }

  async function reject(id) {
    await fetch('/api/reject/'+id, {method:'POST'});
    toast('Dismissed');
    load();
  }

  function toggleContext(id) {
    document.getElementById('ctx-'+id).classList.toggle('open');
  }

  function toast(msg) {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.classList.add('show');
    setTimeout(()=>el.classList.remove('show'), 2800);
  }

  function esc(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function toInputDT(iso) {
    if (!iso) return '';
    try { return new Date(iso).toISOString().slice(0,16); } catch { return ''; }
  }

  load();
  setInterval(load, 30000);
</script>
</body>
</html>`;
}

createServer(app).listen(PORT, () => {
  console.log(`🌐 Review UI running at http://localhost:${PORT}`);
});
