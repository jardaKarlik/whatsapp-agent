# WhatsApp Agent

Monitors specific WhatsApp chats, detects commitments and events using Claude AI, and lets you review + push them to Google Calendar / Google Tasks.

---

## Setup

### 1. Environment
```bash
cp .env.example .env
# fill in your ANTHROPIC_API_KEY
```

### 2. Google credentials
Place your downloaded `credentials.json` (OAuth Desktop app) in this folder.

### 3. Configure watched chats
Edit `config.json`:
```json
{
  "watchedChats": ["Family", "Work Team"],
  "bufferMinutes": 5
}
```
Chat names are matched with case-insensitive `includes()` — partial names work fine.

### 4. Install dependencies
```bash
npm install
```

### 5. First run — connect Google
```bash
npm run server
```
Open http://localhost:3000 and click **Connect Google** → complete the OAuth flow.  
Tokens are saved to `tokens.json` — you only do this once.

### 6. Run everything
```bash
npm start
```
Scan the QR code in your terminal with WhatsApp → the agent is live.

---

## How it works

```
New WhatsApp message
  ↓ (only from watched chats)
Message buffer (5 min window, groups context)
  ↓
Claude API — detects commitments and events
  ↓
Review queue (SQLite)
  ↓
http://localhost:3000 — you approve or dismiss
  ↓
Google Calendar (events) / Google Tasks (commitments)
```

---

## Files

| File | Purpose |
|---|---|
| `index.js` | WhatsApp listener + Claude analysis |
| `server.js` | Express review UI + Google API integration |
| `config.json` | Watched chats and buffer settings |
| `queue.db` | Persistent SQLite queue (auto-created) |
| `tokens.json` | Google OAuth tokens (auto-created) |
| `.env` | API key |

---

## Tips

- The 5-minute buffer groups messages so "let's meet" + "Friday at 6" land as one event
- You can edit the title, description, and datetime directly in the review UI before approving
- Click "context" on any card to see the raw conversation excerpt
- Dismissed items stay in the history at the bottom of the page
- To watch a new chat, just add its name (or partial name) to `config.json` and restart

---

## .gitignore

```
node_modules/
.env
tokens.json
queue.db
.wwebjs_auth/
```
